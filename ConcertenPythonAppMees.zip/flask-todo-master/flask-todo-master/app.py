# Importeer de nodige modules en bibliotheken
from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import requests
from bs4 import BeautifulSoup

#-------------------------------------------------------------------------------------------------------------------------------------------#

#DATABASE

# Opzetten Database
app = Flask(__name__, template_folder='templates') #Flask app met naam app wordt gemaakt, templates wordt aangeroepen voor HTML
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///concerts.sqlite' #SQL framework roept de concerts.sqlite database aan
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False #SQL framework hoeft modifications niet te tracken, SQLite past het automatisch aan
db = SQLAlchemy(app) #Communicatie met database wordt opgezet

# Definieer het Concert-model voor de database
class Concert(db.Model): #db.model is een basisklasse voor databases, class Concert wordt aangeroepen
    id = db.Column(db.Integer, primary_key=True) #Elke rij moet een unieke waarde voor id hebben
    artist = db.Column(db.String(100)) #Artiest invullen, max 100 tekens
    location = db.Column(db.String(100)) #Locatie invullen, max 100 tekens
    date = db.Column(db.Date) #Datum invullen, db.Date zorgt voor opslaan datums

#-------------------------------------------------------------------------------------------------------------#

#HOME > Concerttracker

# Route voor de homepagina
@app.route("/") #/ is homepagina
def home(): #Defineert de home pagina
    concert_list = Concert.query.order_by(Concert.date.asc()) #Sorteer op datum
    return render_template("concert_base.html", concert_list=concert_list) #Na het invullen de geupdate pagina/lijst terugsturen

# Route om een nieuw concert toe te voegen
@app.route("/add", methods=["POST"])
def add():
    # Haal de gegevens op van het formulier op de homepagina, artiest, locatie en datum
    artist = request.form.get("artist")
    location = request.form.get("location")
    date_str = request.form.get("date")

    # Converteer de datum van string naar datetime-object
    date = datetime.strptime(date_str, '%Y-%m-%d').date() #Datum wordt nog als string gebruikt, daarom omzetten

    # Maak een nieuw Concert-object en voeg het toe aan de database
    new_concert = Concert(artist=artist, location=location, date=date) #Geef de waardes door
    db.session.add(new_concert) #Voegt nieuw concert toe aan sessie
    db.session.commit() #Sessie wordt doorgevoerd

    # Stuur de gebruiker terug naar de homepagina
    return redirect(url_for("home"))

# Route om een concert te verwijderen
@app.route("/delete/<int:concert_id>")
def delete(concert_id):
    # Zoek het concert op basis van het concert_id
    concert = Concert.query.get(concert_id)

    # Verwijder het concert uit de database
    db.session.delete(concert)
    db.session.commit()

    # Stuur de gebruiker terug naar de homepagina
    return redirect(url_for("home"))

# ----------------------------------------------------------------------------------------------------------------------------------#

#ARTIESTENZOEKER WEBSCRAPER

# Route voor de zoek artiesten pagina
@app.route('/artiestenzoeker') 
def artiestenzoeker():
    return render_template('artiestenzoeker.html')

# Route om artiestinformatie van een externe bron te schrapen
@app.route("/scrape_artist", methods=["POST"]) #post verzoek = verzenden van gegevens naar een server
def scrape_artist():

    # Haal de artiestnaam op uit music.fandom op de nieuwe pagina
    artist_name = request.form.get("artist_name")

    # Op basis van invoer wordt er gezocht naar een specifieke pagina
    url = f"https://music.fandom.com/wiki/{artist_name.replace(' ', '_')}"

    # Stuur een GET-verzoek naar de URL (haal gegevens op van een bron)
    response = requests.get(url)

    #Kijken of hij de pagina heeft gevonden
    if response.status_code == 200: 

        #BeautifulSoup Framework analyseert de gegevens)
        soup = BeautifulSoup(response.text, 'html.parser')

        # Haal inhoud op uit class="mw-parser-output", dit zijn de gegevens van de artiesten
        mw_parser_output = soup.find('div', class_='mw-parser-output')

        # Haal inhoud op uit id="firstHeading", dit is de titel, zoals Ed Sheeran
        first_heading = soup.find('h1', id='firstHeading')

        # Maak een dictionary om de geschraapte inhoud op te slaan
        scraped_content = {}

        #Gevonden elementen worden toegevoegd aan scraped_content, als hij het niet kan vinden wordt het niet toegevoegd
        if mw_parser_output:
            scraped_content['mw_parser_output'] = str(mw_parser_output)

        if first_heading:
            scraped_content['first_heading'] = str(first_heading)

        # Render de nieuwe pagina met de geschraapte inhoud
        return render_template("artiestenzoeker.html", artist_name=artist_name, scraped_content=scraped_content)
    else:
        # Als het ophalen van de pagina mislukt, geef een foutmelding weer
        return render_template("artiestenzoeker.html", artist_name=artist_name, error_message=f"Failed to retrieve the page. Status code: {response.status_code}")

#--------------------------------------------------------------------------------------------------------------------------#
    
#AANKOMENDE CONCERTEN WEBSCRAPER    

# Route om concertinformatie van een externe bron te schrapen
@app.route('/scrape_concert_info')
def scrape_concert_info():
    # Definieer de URL van de externe bron voor concertinformatie
    url = 'https://www.podiuminfo.nl/concertagenda/'

    # Stuur een GET-verzoek naar de URL
    response = requests.get(url)
    html = response.text

    # Parse de HTML-inhoud van de pagina
    soup = BeautifulSoup(html, 'html.parser')

    # Zoek naar alle elementen met class="concert_rows_info clearfix"
    concert_rows = soup.find_all(class_='concert_rows_info clearfix')

    # Maak een HTML-tabel met aparte kolommen voor de classes 'td_2 last', 'td_3 last' en 'td_4 last'
    html_content = "<table border='1'><tr><th>Column 1</th><th>Column 2</th><th>Column 3</th></tr>"
    for concert_row in concert_rows:
        # Zoek naar de elementen binnen de huidige concertrij met de opgegeven classes
        column_1_elem = concert_row.find(class_='td_2 last')
        column_2_elem = concert_row.find(class_='td_3 last')
        column_3_elem = concert_row.find(class_='td_4 last')

        # Controleer of de elementen zijn gevonden voordat je get_text() aanroept
        column_1 = column_1_elem.get_text(strip=True) if column_1_elem else ""
        column_2 = column_2_elem.get_text(strip=True) if column_2_elem else ""
        column_3 = column_3_elem.get_text(strip=True) if column_3_elem else ""

        # Voeg een nieuwe rij toe aan de tabel met de gevonden informatie
        html_content += f"<tr><td>{column_1}</td><td>{column_2}</td><td>{column_3}</td></tr>"
    html_content += "</table>"

    # Geef de opgehaalde concertinformatie terug
    return html_content

# Route om de concertenpagina te renderen met de opgehaalde concertinformatie
@app.route('/concerten_pagina')
def concerten_pagina():
    # Roep de scrape_concert_info functie aan om de meest recente informatie op te halen
    html_content = scrape_concert_info()

    # Render de template met de opgehaalde concertinformatie
    return render_template('concerten_pagina.html', html_content=html_content)

#-----------------------------------------------------------------------------------------------------------------------------------#

#UITVOEREN APP

# Voer de applicatie uit als dit script wordt uitgevoerd
if __name__ == "__main__":
    # Creëer de database-tabellen als ze nog niet bestaan
    with app.app_context():
        db.create_all()
    # Start de applicatie in de debug-modus
    app.run(debug=True)


